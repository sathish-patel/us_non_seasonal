from django.apps import AppConfig


class PlannerConfig(AppConfig):
    name = 'app_dir.planner'
